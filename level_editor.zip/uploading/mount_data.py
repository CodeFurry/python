import pygame
pygame.init()

class imageCutter:
	def __init__(self, base_path, sheet):
		if isinstance(sheet, str):
			self.sheet = pygame.image.load(f"{base_path}/{sheet}")
		else: self.sheet = sheet

	def cutImages(self, width, height, frame):
		surface = pygame.Surface((width, height), pygame.SRCALPHA)
		surface.blit(self.sheet, (0, 0), (width * frame, 0, width, height))
		return surface

	def cutTilesUndefined(self, width, height, start_hor, start_ver):
		surface = pygame.Surface((width, height), pygame.SRCALPHA)
		surface.blit(self.sheet, (0, 0), (start_hor, start_ver, width, height))
		# pygame.draw.rect(surface, (50, 50, 50), (0, 0, width, height), 1)
		# surface = pygame.transform.scale(surface, (32, 32))
		return surface

	def cutRandomTiles(self, width, height, start_hor, start_ver, scale = None):
		surface = pygame.Surface((width, height), pygame.SRCALPHA)
		surface.blit(self.sheet, (0, 0), (start_hor, start_ver, width, height))
		surface = pygame.transform.scale(surface, scale) if scale != None else surface
		return surface
