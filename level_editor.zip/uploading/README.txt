Just a simple level editor made in Python/Pygame

Credits:
1. Assets: 'Pixel Frog'
2. Python Files: 'CodeFurry'