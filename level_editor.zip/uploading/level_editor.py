#!/bin/python3

import pygame
import mount_data
from json import dump as writeJson
from sys import exit as closeApplication

class editorClass:
	def __init__(self):
		pygame.init()
		self.clock = pygame.time.Clock()
		self.display_size = (832, 632)
		self.DISPLAY = pygame.display.set_mode(self.display_size)
		self.tile_images = {
			"large": self.load_large_tiles(),
			"decor": self.load_decor_tiles(),
			"other": self.load_other_tiles()
		}
		self.avai_types = list(self.tile_images.keys())
		self.tile_data = [0, 0]
		self.inputted_tiles = {
			"large": [],
			"decor": [],
			"other": []
		}
		self.mouse_pressed = False
		self.background = pygame.image.load("data/Background/Brown.png").convert_alpha()
		self.update_info()

	def load_large_tiles(self):
		tiles = [
			((48, 48), (0, 0)),
			((48, 48), (8*12, 0)),
			((48, 48), (0, 8*8)),
			((48, 48), (8*12, 8*8)),
			((48, 48), (0, 8*16)),
			((48, 48), (8*12, 8*16)),
			((48, 48), (8*34, 8*8))
		]
		images = []
		tile_images = []

		base_path = "data/Terrain"
		main_path = "Terrain (16x16).png"

		for tile_data in tiles:
			tile = mount_data.imageCutter(base_path, main_path)
			image = tile.cutRandomTiles(tile_data[0][0], tile_data[0][1], tile_data[1][0], tile_data[1][1])
			images.append(image)

		for image in images:
			sheet = mount_data.imageCutter(base_path=None, sheet=image)

			for row in range(3):
				for col in range(3):
					tile = sheet.cutRandomTiles(16, 16, col * 16, row * 16, (32, 32))
					tile_images.append(tile)

		return tile_images

	def load_decor_tiles(self):
		tiles = [
			((32, 32), (0 + 48, 0)),
			((32, 32), (8*12 + 48, 0)),
			((32, 32), (0 + 48, 8*8)),
			((32, 32), (8*12 + 48, 8*8)),
			((32, 32), (0 + 48, 8*16)),
			((32, 32), (8*12 + 48, 8*16)),
			((32, 32), (8*34 + 48, 8*8))
		]
		images = []

		base_path = "data/Terrain"
		main_path = "Terrain (16x16).png"

		for tile_data in tiles:
			tile = mount_data.imageCutter(base_path, main_path)
			image = tile.cutRandomTiles(tile_data[0][0], tile_data[0][1], tile_data[1][0], tile_data[1][1])
			images.append(image)

		return images

	def load_other_tiles(self):
		tiles = [
			((8*6, 8*2), (8*24, 0)),
			((8*2, 8*2), (8*24, 8*2)),
			((8*4, 8*4), (8*26, 8*2)),
			((8*2, 8*6), (8*30, 0)),

			((8*6, 8*2), (8*24, 0 + 8*8)),
			((8*2, 8*2), (8*24, 8*2 + 8*8)),
			((8*4, 8*4), (8*26, 8*2 + 8*8)),
			((8*2, 8*6), (8*30, 0 + 8*8)),

			((8*6, 8*2), (8*24, 0 + 8*16)),
			((8*2, 8*2), (8*24, 8*2 + 8*16)),
			((8*4, 8*4), (8*26, 8*2 + 8*16)),
			((8*2, 8*6), (8*30, 0 + 8*16)),

			((8*6, 8*2), (8*24 + 8*10, 0 + 8*16)),
			((8*2, 8*2), (8*24 + 8*10, 8*2 + 8*16)),
			((8*4, 8*4), (8*26 + 8*10, 8*2 + 8*16)),
			((8*2, 8*6), (8*30 + 8*10, 0 + 8*16)),

			((8*6, 8), (8*34, 0)),
			((8*6, 8), (8*34, 0 + 8*2)),
			((8*6, 8), (8*34, 0 + 8*4))
		]
		images = []

		base_path = "data/Terrain"
		main_path = "Terrain (16x16).png"

		for tile_data in tiles:
			tile = mount_data.imageCutter(base_path, main_path)
			image = tile.cutRandomTiles(tile_data[0][0], tile_data[0][1], tile_data[1][0], tile_data[1][1])
			images.append(image)

		return images

	def backup_map(self):
		with open("backup.json", "w") as backup_file:
			writeJson(self.inputted_tiles, backup_file)

	def save_map(self):
		tile_filled = False
		for tile_type in self.inputted_tiles:
			for tile in self.inputted_tiles[tile_type]:
				if tile:
					tile_filled = True
		if tile_filled:
			with open("map.json", "w") as json_file:
				try:
					writeJson(self.inputted_tiles, json_file)
				except: self.backup_map()

	def get_mouse_pos(self):
		mouse = pygame.mouse.get_pos()
		return (mouse[0] // 8, mouse[1] // 8)

	def update_info(self):
		self.info_tile = self.tile_images[self.avai_types[self.tile_data[0]]][self.tile_data[1]]
		self.info_rect = self.info_tile.get_rect(topright = (832, 0))

	def draw_info(self):
		image = self.tile_images[self.avai_types[self.tile_data[0]]][self.tile_data[1]].copy(); image.set_alpha(128)
		dest = self.get_mouse_pos()
		self.DISPLAY.blit(image, (dest[0] * 8, dest[1] * 8))

	def draw_bg(self):
		for row in range(10):
			for col in range(13):
				self.DISPLAY.blit(self.background, (col * 64, row * 64))

	def input_tiles(self):
		mouse = pygame.mouse.get_pressed()
		key = pygame.key.get_pressed()

		if not self.mouse_pressed:
			if key[pygame.K_LCTRL]:
				if mouse[0]:
					self.mouse_pressed = True

					if self.tile_data[0] < len(self.avai_types) - 1:
						self.tile_data[1] = 0; self.tile_data[0] += 1
					else: self.tile_data[1] = 0; self.tile_data[0] = 0

					self.update_info()

				if mouse[2]:
					self.mouse_pressed = True

					if self.tile_data[1] < len(self.tile_images[self.avai_types[self.tile_data[0]]]) - 1:
						self.tile_data[1] += 1
					else: self.tile_data[1] = 0

					self.update_info()

			else:
				if mouse[0]:
					self.mouse_pressed = True

					dest = self.get_mouse_pos()
					dest = (dest[0] * 8, dest[1] * 8)
					self.inputted_tiles[self.avai_types[self.tile_data[0]]].append((self.tile_data[1], dest))

				if mouse[2]:
					self.mouse_pressed = True

					dest = self.get_mouse_pos()
					dest = (dest[0] * 8, dest[1] * 8)

					for tile_type in self.avai_types:
						for tile_index, tile_data in enumerate(self.inputted_tiles[tile_type]):
							if dest == tile_data[1]:
								self.inputted_tiles[tile_type].pop(tile_index)

		if self.mouse_pressed:
			if not mouse[0] and not mouse[1] and not mouse[2]:
				self.mouse_pressed = False

	def draw_tiles(self):
		for tile_type in self.avai_types:
			for tile_data in self.inputted_tiles[tile_type]:
				self.DISPLAY.blit(self.tile_images[tile_type][tile_data[0]], tile_data[1])

		self.draw_info()

	def update_editor(self):
		''' this function will run all the other functions '''
		self.input_tiles()
		self.draw_bg()
		self.draw_tiles()

	def execute(self):
		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					self.save_map(); pygame.quit(); closeApplication()

			self.DISPLAY.fill((50, 50, 50)); self.update_editor()
			pygame.display.update(); self.clock.tick(60)

editor_object = editorClass()
editor_object.execute()
